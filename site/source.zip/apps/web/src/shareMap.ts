import {formatTickRoundedPrice} from './mapFormatting';
// SPDX-License-Identifier: MPL-2.0
import { carryRangeEdgesForward, deriveSessionFinalIb,  type JournalSession } from "@ib-field-notes/domain";
import { createSessionClock } from "@ib-field-notes/session-templates";
import { formationSteps } from "./formationSteps";
import { collapseNearbyMapObservations, mapMoveThreshold, mapObservationX } from "./mapGeometry";
import {qualityColors,type LevelQuality,type LevelTier} from './levelQuality';

export type ShareMapLevel = { label: string; high: number; low: number; code?: string;
  role?: 'support' | 'resistance' | 'reference'; quality?: LevelQuality; tier?:LevelTier; detail?: string; activity?:string; references?:string };
export const SHARE_MAP_STYLES=`    .map-bg { fill: #1b1a1c; stroke: #3c373c; stroke-width: 2; }
    .map-empty { font: 600 24px Arial, sans-serif; fill: #b5becb; }
    .on-line { stroke: #bebec2; stroke-width: 1.5; opacity: .72; }
    .on-label { fill: #d9d7da; }
    .ib-band { fill: #cb5690; opacity: .24; }
    .rth-band { opacity: .08; }
    .step-start { stroke: #f45ca9; stroke-width: 1; opacity: .3; }
    .ib-edge { stroke: #f45ca9; stroke-width: 3; }
    .ib-mid { stroke: #bb8ba3; stroke-width: 1.5; stroke-dasharray: 9 8; }
    .mid-line { stroke: #c5adff; stroke-width: 1.5; stroke-dasharray: 9 8; }
    .mid-label { fill: #c5adff; }
    .map-price { font: 500 18px Arial, sans-serif; fill: #b9b6c0; }
    .price-path { fill: none; stroke: #f7d5e5; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; }
    .price-dot { fill: #f7d5e5; stroke: #1b1a1c; stroke-width: 1.5; }
    .price-dot[data-latest="true"] { fill: #f2b84b; }
    .latest-ring { fill: #f2b84b; opacity: .2; }
    .ib-line { stroke: #f45ca9; stroke-width: 2; opacity: .7; }
    .level-line { stroke: ${qualityColors.common}; stroke-width: 1.5; stroke-dasharray: 7 6; opacity: .75; }
    .level-leader { fill: none; stroke: ${qualityColors.common}; stroke-width: 1; opacity: .6; }
    ${Object.entries(qualityColors).map(([quality,color]) => `
      .level-line[data-quality="${quality}"], [data-quality="${quality}"] .level-leader { stroke:${color}; }
      [data-quality="${quality}"] .level-label { fill:${color}; }`).join('')}
    .map-label { font: 600 19px Arial, sans-serif; }
    .ib-label { fill: #f5bfd9; }
    .level-label { fill: ${qualityColors.common}; }
    .map-axis { font: 700 20px Arial, sans-serif; fill: #f4d5e5; }
    .axis-cell { fill: #211f22; stroke: #393439; stroke-width: 1; }
    .map-grid { stroke: #ffffff; stroke-width: 1; opacity: .06; }
    .gutter-line { stroke: #36343a; stroke-width: 1; }
    .label-leader { fill: none; stroke: #b5becb; stroke-width: 1; opacity: .28; }
    .stat-meaning { font: 500 16px Arial, sans-serif; fill: #b5becb; }
`;

type Reference = { label: string; price: number; tone: "on" | "ib" | "mid" | "level" };
export const shareLevelCode = (level: ShareMapLevel, index: number) => level.code ?? `L${index+1}`;
const xml = (value: string) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");

/** Only selected market facts enter the drawing. No notes, IDs or audit records are serialized. */
export function buildShareMap(session: JournalSession, options: {
  through?: 'ON'|'15R'|'A'|'B'|'RTH';
  overnight: { high: number | null; low: number | null } | null;
  includePath: boolean;
  includeCurrentOrClose: boolean;
  levels: ShareMapLevel[];
  rangeLabels: { high: string; low: string } | null;
}) {
  const clock = createSessionClock(session.market);
  const checkpoints = session.market.checkpoints;
  const at = (local: string) => clock.checkpointInstant(session.rthDate, local).epochMilliseconds;
  const boundaries = [checkpoints.overnightLock, checkpoints.fifteenMinuteLock, checkpoints.aLock, checkpoints.ibLock].map(at);
  const finalIb = deriveSessionFinalIb(session);
  const a = carryRangeEdgesForward(session.aPeriod, session.fifteenMinute);
  const b = carryRangeEdgesForward(session.bPeriod, session.fifteenMinute, a, ...session.bSnapshots);
  const hasData = (range: typeof session.aPeriod) => range.high !== null || range.low !== null || range.cp !== null;
  const candidates = [
    session.fifteenMinute,
    hasData(session.aPeriod) || session.aPeriodHistory.length ? a : null,
    hasData(session.bPeriod) || session.bPeriodHistory.length || session.bSnapshots.length ? finalIb ?? b : null,
  ];
  const ranges = candidates.flatMap((range, column) => range?.high != null && range.low != null
    ? [{ high: range.high, low: range.low, column }] : []);
  const primary = ranges.at(-1);
  const segments=options.through?({ON:0,'15R':1,A:2,B:3,RTH:4}[options.through]):4;
  const horizon=segments===1?15:segments===2?30:segments===3?45:100;
  const normalize=(percent:number)=>percent*100/horizon;
  const steps = ranges.flatMap(range => formationSteps(range,
    range.column === 0 ? session.fifteenMinuteHistory : range.column === 1 ? session.aPeriodHistory
      : [...session.bPeriodHistory, ...session.bSnapshots],
    boundaries[range.column], boundaries[range.column + 1], range.column,
    ranges.filter(r => r.column < range.column).at(-1)));
  const start = primary ? boundaries[0] : clock.overnightStart(session.rthDate).epochMilliseconds;
  const observations = session.cpObservations.filter(point => {
    const time = Date.parse(point.observedAt);
    return time >= start && time <= at(checkpoints.studyClose);
  }).sort((left, right) => left.observedAt.localeCompare(right.observedAt));
  const latest = observations.at(-1);
  const current = options.includeCurrentOrClose ? latest : undefined;
  const visibleObservations = options.includePath ? observations : current ? [current] : [];
  const references: Reference[] = [
    ...(options.overnight?.high != null ? [{ label: "ONH", price: options.overnight.high, tone: "on" as const }] : []),
    ...(options.overnight?.low != null ? [{ label: "ONL", price: options.overnight.low, tone: "on" as const }] : []),
    ...(options.overnight?.high != null && options.overnight.low != null ? [{label:'ON mid',price:(options.overnight.high+options.overnight.low)/2,tone:'mid' as const}]:[]),
    ...(primary ? [{ label: options.rangeLabels?.high ?? "IBH", price: primary.high, tone: "ib" as const }, { label: options.rangeLabels?.low ?? "IBL", price: primary.low, tone: "ib" as const }] : []),
    ...(primary ? [{label:options.through==='15R'?'15R mid':options.through==='A'?'A mid':'IB mid',price:(primary.high+primary.low)/2,tone:'mid' as const}]:[]),
    ...options.levels.flatMap(level => level.high === level.low
      ? [{ label: level.label, price: level.low, tone: "level" as const }]
      : [{ label: `${level.label} H`, price: level.high, tone: "level" as const }, { label: `${level.label} L`, price: level.low, tone: "level" as const }]),
  ];
  const prices = [...references.map(ref => ref.price), ...steps.flatMap(step => [step.high, step.low]), ...visibleObservations.map(point => point.price)];
  const background = '<rect x="64" y="254" width="952" height="500" rx="24" class="map-bg"/>';
  if (!prices.length) return { svg: `${background}<text x="540" y="510" text-anchor="middle" class="map-empty">Awaiting recorded structure</text>`, overflow: false };
  const span = Math.max(Math.max(...prices) - Math.min(...prices), session.market.tickSize * 16);
  const padding = Math.max(session.market.tickSize * 4, span * .1);
  const minimum = Math.min(...prices) - padding, maximum = Math.max(...prices) + padding;
  const plot = { x: 196, y: 312, width: options.levels.length ? 748 : 804, height: 370 };
  const x = (percent: number) => plot.x + percent / 100 * plot.width;
  const phaseX=(percent:number)=>x(normalize(percent));
  const y = (price: number) => plot.y + (maximum - price) / (maximum - minimum) * plot.height;
  const rth = collapseNearbyMapObservations(observations.filter(point => Date.parse(point.observedAt) > boundaries[3]), mapMoveThreshold(session.market.tickSize, span));
  const displayed = options.includePath
    ? primary ? [...observations.filter(point => Date.parse(point.observedAt) <= boundaries[3]), ...rth] : observations
    : current ? [current] : [];
  const firstRth = rth[0] ? Date.parse(rth[0].observedAt) : null;
  const lastRth = rth.at(-1) ? Date.parse(rth.at(-1)!.observedAt) : null;
  const pointPercent = (instant: string) => {
    const time = Date.parse(instant);
    if (primary) return normalize(mapObservationX(time, boundaries, firstRth, lastRth));
    const first = Date.parse(observations[0].observedAt), last = Date.parse(observations.at(-1)!.observedAt);
    return first === last ? 6 : 6 + 88 * (time - first) / (last - first);
  };
  const pointX = (instant: string) => x(pointPercent(instant));
  const band = finalIb && primary && segments===4
    ? `<rect x="${x(45)}" y="${y(primary.high)}" width="${plot.width * .55}" height="${Math.max(1, y(primary.low) - y(primary.high))}" class="ib-band rth-band"/>` : "";
  const silhouette = steps.map(step => `<g class="formation-step" data-left="${step.left}" data-width="${step.width}">
    <rect x="${phaseX(step.left)}" y="${y(step.high)}" width="${plot.width * step.width / horizon}" height="${Math.max(1, y(step.low) - y(step.high))}" class="ib-band" style="opacity:${[.24,.31,.38][Math.min(2,Math.floor(step.left/15))]}"/>
    <line x1="${phaseX(step.left)}" y1="${y(step.high)}" x2="${phaseX(step.left)}" y2="${y(step.low)}" class="step-start"/>
    <path d="M ${phaseX(step.left)} ${y(step.high)} H ${phaseX(step.left + step.width)} M ${phaseX(step.left)} ${y(step.low)} H ${phaseX(step.left + step.width)}" class="ib-edge"/>
    </g>`).join("");
  // Midpoints are map-only references. Reuse the existing IB midpoint line;
  // never add a second line or create a carried Significant Level.
  const midpoint = primary ? `<line x1="${plot.x}" y1="${y((primary.high + primary.low) / 2)}" x2="${x(100)}" y2="${y((primary.high + primary.low) / 2)}" class="ib-mid"/>` : "";
  const lines = references.filter(ref => ref.tone !== 'level').map(ref => {
    if(ref.tone==='mid'&&primary&&ref.price===(primary.high+primary.low)/2)return '';
    const end = ref.tone === "ib" ? Math.max(0, ...steps.filter(step => step.high === ref.price || step.low === ref.price).map(step => step.left + step.width)) : 0;
    return `${end > 0 ? `<line x1="${plot.x}" y1="${y(ref.price)}" x2="${phaseX(end)}" y2="${y(ref.price)}" class="label-leader"/>` : ""}
      <line x1="${phaseX(end)}" y1="${y(ref.price)}" x2="${x(100)}" y2="${y(ref.price)}" class="${ref.tone}-line"/>`;
  }).join("");
  // Match the dashboard: range names on the left, selected L markers on the right.
  const labelPositions = (prices: number[]) => {
    const positions: number[]=[];
    prices.forEach((price,index) => positions.push(Math.max(y(price), index ? positions[index-1]+42 : plot.y+14)));
    for(let index=positions.length-1;index>=0;index--) positions[index]=Math.min(positions[index],
      index===positions.length-1 ? plot.y+plot.height-22 : positions[index+1]-42);
    return positions;
  };
  const ordered = references.filter(ref => ref.tone !== 'level').sort((left,right)=>right.price-left.price);
  const labelY=labelPositions(ordered.map(ref=>ref.price));
  const compactLabel = (label:string) => label === 'DEV HIGH' ? 'IBH' : label === 'DEV LOW' ? 'IBL' : label;
  const labels = ordered.map((ref, index) => `<g class="map-reference ${ref.tone}-reference">
    <title>${xml(ref.label)} ${formatTickRoundedPrice(ref.price,session.market.tickSize)}</title>
    <path d="M 188 ${labelY[index]} L ${plot.x} ${y(ref.price)}" class="label-leader"/>
    <text x="182" y="${labelY[index]}" text-anchor="end" class="map-label ${ref.tone}-label">${xml(compactLabel(ref.label))}</text>
    <text x="182" y="${labelY[index]+22}" text-anchor="end" class="map-price">${formatTickRoundedPrice(ref.price,session.market.tickSize)}</text>
    </g>`).join("");
  const levelMarkers=options.levels.map((level,index)=>({...level, code:shareLevelCode(level,index)}))
    .sort((a,b)=>(b.high+b.low)-(a.high+a.low));
  const levelY=labelPositions(levelMarkers.map(level=>(level.high+level.low)/2));
  const levelLines=levelMarkers.map(level=>[...new Set([level.low,level.high])].map(price=>
    `<line x1="${plot.x}" y1="${y(price)}" x2="${x(100)}" y2="${y(price)}" class="level-line" data-role="${level.role ?? 'reference'}" data-quality="${level.quality ?? 'common'}"/>`).join('')).join('');
  const levelLabels=levelMarkers.map((level,index)=>`<g class="map-reference level-reference" data-quality="${level.quality ?? 'common'}">
    <title>${xml(level.code)} · ${xml(level.label)} · ${formatTickRoundedPrice(level.low,session.market.tickSize)}${level.high===level.low?'':`–${formatTickRoundedPrice(level.high,session.market.tickSize)}`}</title>
    <path d="M ${x(100)} ${y(level.high)} V ${y(level.low)} M ${x(100)} ${y((level.high+level.low)/2)} L ${x(100)+10} ${levelY[index]}" class="level-leader"/>
    <text x="${x(100)+14}" y="${levelY[index]+6}" class="map-label level-label">${xml(level.code)}</text>
  </g>`).join('');
  const path = displayed.length > 1 ? `<polyline points="${displayed.map(point => `${pointX(point.observedAt)},${y(point.price)}`).join(" ")}" class="price-path"/>` : "";
  const dots = displayed.map(point => `<circle cx="${pointX(point.observedAt)}" cy="${y(point.price)}" r="5" class="price-dot" data-x="${pointPercent(point.observedAt)}" data-latest="${current?.id===point.id}"/>`).join("");
  const latestRing=current && displayed.some(point=>point.id===current.id) ? `<circle cx="${pointX(current.observedAt)}" cy="${y(current.price)}" r="8" class="latest-ring"/>` : '';
  const axis = primary ? ['15R','A','B / IB','RTH'].slice(0,segments).map((label,index)=>
    `<rect x="${phaseX(index*15)}" y="700" width="${plot.width*(index===3?55:15)/horizon}" height="34" class="axis-cell"/>
     <text x="${phaseX([7.5,22.5,37.5,72.5][index])}" y="724" text-anchor="middle" class="map-axis">${label}</text>`).join('')
    : `<rect x="${plot.x}" y="700" width="${plot.width}" height="34" class="axis-cell"/><text x="${x(50)}" y="724" text-anchor="middle" class="map-axis">Overnight observations</text>`;
  const grid=Array.from({length:6},(_,index)=>`<line x1="${plot.x}" y1="${plot.y+(index+1)*plot.height/7}" x2="${x(100)}" y2="${plot.y+(index+1)*plot.height/7}" class="map-grid"/>`).join('');
  const gutters=`<line x1="${plot.x}" y1="${plot.y}" x2="${plot.x}" y2="${plot.y+plot.height}" class="gutter-line"/>`+
    (options.levels.length ? `<line x1="${x(100)}" y1="${plot.y}" x2="${x(100)}" y2="${plot.y+plot.height}" class="gutter-line"/>` : '');
  const minutes=(index:number)=>Math.round((boundaries[index]-boundaries[0])/60_000);
  const legend=`<text x="84" y="278" class="stat-meaning">${primary?'Pink: '+(options.through==='15R'?'15R':options.through==='A'?'A':'IB'):''}${options.overnight?(primary?' · ':'')+'Gray: ON':''} · Violet: midpoint${options.includePath||current?' · Dots: price entries':''}${current?' · Gold: latest':''}${options.levels.length?' · L: levels':''}</text>
    <text x="84" y="300" class="stat-meaning">${options.overnight?'ON: overnight · ':''}H/L: high/low${primary ? ` · ${[`15R: ${minutes(1)} min`,`A: ${minutes(2)} min`,`B/IB: ${minutes(3)} min`,'RTH: regular session'].slice(0,segments).join(' · ')}` : ''}</text>`;
  return {svg:`${background}${legend}${grid}${band}${silhouette}${midpoint}${lines}${levelLines}${path}${latestRing}${dots}${gutters}${labels}${levelLabels}${axis}`, overflow:ordered.length*42>plot.height||levelMarkers.length*42>plot.height};
}
