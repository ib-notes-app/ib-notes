# IB Notes — application source

Open the app: https://ib-notes-app.github.io/ib-notes/
Guides: https://github.com/ib-notes-app/ib-notes#start-here

This source copy contains application code only. No CSVs, price history, data packs, user journals, backups or example records are supplied. Optional history comes only from files the user deliberately supplies and is permitted to use.

For developers: Node.js 22+, npm and Python 3. Run `npm ci`, then `npm run build:public`. The public package is built from its own cleaned source copy.

Source: MPL 2.0 (LICENSE). Dependencies keep their licenses. Software licensing grants no rights to third-party data.
