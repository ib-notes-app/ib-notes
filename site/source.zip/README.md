# IB Notes — blank-slate source

This is the application source for the public-blank build. No market history, user journals, Study Packs, research or internal phone fixtures are supplied. The internal phone fixture module is a nonfunctional stub; private JSON imports have type-only declarations and are eliminated by the public build.

Requires Node 20.19+, npm and Python 3. Run npm ci, then npm run build:public. Use build:public for this edition; the ordinary private build expects reference files which are intentionally absent.

Source: MPL 2.0 (LICENSE). Dependencies retain their licenses. Packaging is local; no hosting or data service is created.
